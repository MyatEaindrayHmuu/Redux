/* import { compose, pipe} from "lodash/fp";

let input = "   JavaScript   ";
let output = "<div>" + input.trim() + "</div>";

trim = str => str.trim();
wrap = type => str => `<${type}>${str}</${type}>`;
toLowerCase = str => str.toLowerCase();

transform = pipe(trim, toLowerCase, wrap("spam"));
console.log(transform(input)); */

//immutability
/*const person = {
    name: "John",
    address: {
        country: "USA",
        city: "San Francisco"
    }

};
const updated = {...person, name: "BOB"}; //need deep copy for effective change
updated.address.city = "New York";
console.log(person); */ 
/*
//updating arrays
const numbers = [1,2,3];

//adding
const index = numbers.indexOf(2);
const added = [...numbers.slice(0, index), 4, ...numbers.slice.index];

//removing
const removed = numbers.filter(n => n !== 2);

//updating
const updated = numbers.map(n => n === 2 ? 20 : n);


//immutable
import { map} from 'immutable';
let book = Map({ title:"harry potter"});
function published(book){
    return book.set("isPublished ", true);
}
book = publish(book);
console.log(book.toJS());

//immer
import { produce} from 'immer';
let book = Map({ title:"harry potter"});
function published(book){
    return produce(book, draftBook => {
        draftBook.isPublished = true; //is where mutated
    });
}
let updated = publish(book);
console.log(book);
console.log(updated); */

//dispatching actions
import store from './store'; //here don't use paratheses bec we use store as default object
import * as actions from './actiontypes';
const unsubscribe = store.subscribe(() => {
    console.log("Store changed!", store.getState());
});

store.dispatch({
    type: actions.BUG_ADDED,
    payload: {
        description: "Bug1"
    }
});

unsubscribe();

store.dispatch({
    type: actions.BUG_REMOVED,
    payload: {
        id: 1
    }
});

console.log(store.getState());